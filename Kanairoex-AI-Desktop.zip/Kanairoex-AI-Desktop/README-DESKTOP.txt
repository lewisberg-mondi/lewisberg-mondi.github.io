Kanairoex AI — Desktop
======================

Option A (recommended on Windows if you install Node.js):
  1. Install Node.js from https://nodejs.org
  2. Open this folder in Command Prompt / PowerShell
  3. Run:  npm install
  4. Run:  npm start

Option B (quick — no Node install):
  Double-click  Start-Kanairoex-AI.bat
  Opens in Microsoft Edge or Chrome as an app window.

Option C (Linux/macOS):
  ./Start-Kanairoex-AI.sh
  or: npm install && npm start

Icon: icon.png (your Kanairoex logo)
