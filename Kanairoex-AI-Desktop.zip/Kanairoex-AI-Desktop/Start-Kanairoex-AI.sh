#!/usr/bin/env bash
cd "$(dirname "$0")"
if command -v electron >/dev/null 2>&1; then
  exec electron .
fi
if command -v google-chrome >/dev/null 2>&1; then
  exec google-chrome --app="file://$(pwd)/www/index.html" --disable-web-security --user-data-dir=/tmp/kanairoex-profile
fi
if command -v chromium-browser >/dev/null 2>&1; then
  exec chromium-browser --app="file://$(pwd)/www/index.html" --disable-web-security --user-data-dir=/tmp/kanairoex-profile
fi
xdg-open "www/index.html" 2>/dev/null || open "www/index.html" 2>/dev/null
