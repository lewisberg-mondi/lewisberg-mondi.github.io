// Preload bridge — reserved for future native hooks
window.addEventListener('DOMContentLoaded', () => {
  document.documentElement.setAttribute('data-kanairoex-desktop', '1');
});
