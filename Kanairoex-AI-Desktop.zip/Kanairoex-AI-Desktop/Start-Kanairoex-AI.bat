@echo off
title Kanairoex AI
cd /d "%~dp0"
where electron >nul 2>&1
if %ERRORLEVEL%==0 (
  electron .
  exit /b
)
REM Prefer Edge/Chrome app mode for a desktop-like window
set URL=%~dp0www\index.html
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="file:///%URL:\=/%" --disable-web-security
  exit /b
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
  start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="file:///%URL:\=/%" --disable-web-security --user-data-dir="%TEMP%\kanairoex-profile"
  exit /b
)
start "" "%URL%"
